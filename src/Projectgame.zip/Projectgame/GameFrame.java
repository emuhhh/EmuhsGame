package Projectgame;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

public class GameFrame extends JFrame {
    public static JPanel panelObjekt;
    public static PlayerFigure player1;
    public static ArrayList<Bullet> bullets = new ArrayList<>();

    public static void main(String[] args) {
        GameFrame fenster = new GameFrame();
        fenster.setName("Dodge Game");
        fenster.setSize(1000, 1000);
        fenster.setVisible(true);
        panelObjekt = new Screen();
        panelObjekt.setBackground(Color.DARK_GRAY);
        fenster.add(panelObjekt);
        player1 = new PlayerFigure();
        panelObjekt.addKeyListener(new KeyHandler());
        panelObjekt.addMouseListener(new MouseHandler());
        Timer counter = new Timer();
        counter.scheduleAtFixedRate(new Repaint(), 0, 1000 / 144);
        new Timer().scheduleAtFixedRate(new Update(), 0, 1000 / 200);

    }

    public static class Repaint extends TimerTask {
        @Override
        public void run() {
            double z = 0.06;
            if (Math.random() < 0.5) {
                // x
                if (Math.random() < 0.5) {
                    // x = 0
                    if (Math.random() < z)
                        GameFrame.bullets.add(new Bullet(0, (int) (Math.random() * GameFrame.panelObjekt.getHeight()), 0.5, 0));
                } else {
                    if (Math.random() < z)
                        GameFrame.bullets.add(new Bullet(GameFrame.panelObjekt.getWidth(), (int) (Math.random() * GameFrame.panelObjekt.getHeight()), -0.5, 0));
                }
            } else {
                // y
                if (Math.random() < 0.5) {
                    // x = 0
                    if (Math.random() < z)
                        GameFrame.bullets.add(new Bullet((int) (Math.random() * GameFrame.panelObjekt.getWidth()), 0, 0, 0.5));
                } else {
                    if (Math.random() < z)
                        GameFrame.bullets.add(new Bullet((int) (Math.random() * GameFrame.panelObjekt.getWidth()), GameFrame.panelObjekt.getHeight(), 0, -0.5));
                }
            }
            for (Bullet b : GameFrame.bullets) b.update();
            GameFrame.panelObjekt.repaint();

        }
    }



    public static class Update extends TimerTask {
        @Override
        public void run() {
            GameFrame.player1.update(bullets);

        }
    }
}