package Projectgame;

import java.awt.*;
import java.util.ArrayList;
public class PlayerFigure {
    private float x = 100;
    private float y = 100;
    private Integer clickedX;
    private Integer clickedY;
    private int width = 30;
    private int height = 30;

    public void draw(Graphics2D zeichner) {
        zeichner.setColor(Color.CYAN);
        zeichner.fillOval((int) x, (int) y, width, height);
        if (clickedX != null && clickedY != null)
            zeichner.drawOval(clickedX, clickedY, 1, 1);
    }

    public void update(ArrayList<Bullet> bullets) {
        for (int i = 0; i < bullets.size();i++){
            if( x - width/2 > (GameFrame.bullets.get(i).x + GameFrame.bullets.get(i).width) && ( x + width/2 < (GameFrame.bullets.get(i).x)) ){
                System.out.println("Game Over !");
            }

        }
        if (!(clickedX == null && clickedY == null)) {
            float offX = clickedX - x - width / 2;
            float offY = clickedY - y - height / 2;


            if (Math.abs(offX) > 1 || Math.abs(offY) > 1) {
                float distance = (float) Math.sqrt(offX * offX + offY * offY);
                x += offX / distance;
                y += offY / distance;

            }



        }


        }


    public void saveCLickedPoint(int x, int y) {
        clickedX = x;
        clickedY = y;
    }
}



