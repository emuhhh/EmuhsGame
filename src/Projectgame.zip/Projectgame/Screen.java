package Projectgame;

import javax.swing.*;
import java.awt.*;

public class Screen extends JPanel {
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D zeichner = (Graphics2D) g;
        GameFrame.player1.draw(zeichner);
        for (int i = 0; i < GameFrame.bullets.size();i++){
            GameFrame.bullets.get(i).draw(zeichner);
        }

    }
}
